package com.eureka.server.eurekaApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaAppApplication.class, args);
	}

}
