package com.eureka.server.eurekaApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
