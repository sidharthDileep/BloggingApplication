package com.api.gateway.gatewayApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
